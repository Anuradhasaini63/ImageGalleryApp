import { useState } from 'react'
import './App.css'
import ImageGallery from './ImageGallery'


function App() {

  const images =[
    {
        id:1, url:"https://cdn.pixabay.com/photo/2022/10/10/05/25/rottweiler-7510792_1280.jpg", title:"Image One"
    },
    {
        id:2, url:"https://cdn.pixabay.com/photo/2024/03/31/23/25/butterfly-8667752_640.png", title:"Image Two"
    },
    {
        id:3, url:"https://cdn.pixabay.com/photo/2024/11/23/08/18/christmas-9218404_640.jpg", title:"Image Three"
    }
]

  return (
    <>
     <h1 className='text-red-900'>Image Gallery App</h1>
     <ImageGallery images={images} />
    </>
  )
}

export default App
