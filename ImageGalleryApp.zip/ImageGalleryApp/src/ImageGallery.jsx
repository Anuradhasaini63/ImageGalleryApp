import React from 'react'



const ImageGallery = ({images}) => {

  return (
   <>
       <div className='imagegallery flex'>
       {    
            images.map((image)=>(
               <div key={image.id} className='image mx-8 w-[300px] h-[300px] p-4'>
                 <img src={image.url} alt={image.title} className='w-[300px] h-full object-cover' />
                 </div>
            ))
       }
       
       </div>
   </>
  )
}

export default ImageGallery